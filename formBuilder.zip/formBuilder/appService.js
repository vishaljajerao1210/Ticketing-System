app.factory('formBuilderService', function($http) {
    var service = {};
 
  
    service.getFieldsByLOB = function(lob) {
        debugger

       var formObjects={};



        if(lob=='MOTOR')
        {
    formObjects={
            
            noOfFields:4,
            sections:[
                {
                name:"General Information",
                fields:[
                    {
                        fieldName:"General Employee Name",
                        fieldType:"text",
                        fieldLabel:"Enter Employee Name",
                        fieldId:"empName",
                        isMandatory:true,
                        isVisible:false,
                        callBack:"",
                        arguements:{},
                        model:"bob",
                       pattern:"",
                        isMultiValued:false,
                        class:"",
                        minLength:"3",
                        maxLength:"10",
                        conditionalVisibility:{
                          expression:"'General Employee Fruits' == 'Orange' && 'General Employee Vegetables' == 'Tomato'",
                          value:true,
                          dependents:['General Employee Fruits','General Employee Vegetables']
                        },
                        validations:
                        [
                            {
                                property:"required",
                                validationMessage:"Employee Name is Mandatory",
                                className:""
                            },
                            {
                                property:"minlength",
                                validationMessage:"Employee Name is should be minimum of 3 letters",
                                className:""
                            },
                            {
                                property:"maxlength",
                                validationMessage:"Employee Name is should be Maximum of 10 letters",
                                className:""
                            },
                            {
                                property:"pattern",
                                validationMessage:"Employee Name is not in a valid pattern",
                                className:""
                            }
                        ]
                       
                    
                    },
                    {
                        fieldName:"General Employee Fruits",
                        fieldType:"dropdown",
                        fieldLabel:"Select Fruit",
                        fieldId:"empFruits",
                        isMandatory:false,
                        isVisible:true,
                        fieldOptions:["X","Y"],
                        callBack:"getFruitList",
                      pattern:"",
                        isMultiValued:false,
                        class:"",
                        model:"Banana",
                
                        minLength:"",
                        maxLength:"",
                        validations:
                         [
                            {
                                property:"required",
                                validationMessage:"Employee Fruits is Mandatory",
                                className:""
                            }
                        ]
                
                
                    },
                    {
                        fieldName:"General Employee Vegetables",
                        fieldType:"dropdown",
                        fieldLabel:"Select Vegetable",
                        fieldId:"empVegetables",
                        isMandatory:true,
                        isVisible:true,
                        fieldOptions:["A","B"],
                        model:"Tomato",
                        callBack:"getVegetableList",
                        pattern:"",
                        isMultiValued:false,
                        class:"",
                        minLength:"",
                        maxLength:"",
                        validations:
                        [
                           {
                               property:"required",
                               validationMessage:"Employee Vegetables is Mandatory"
                           }
                       ]
                
                
                    },
                    {
                        fieldName:"General Employee Contact No",
                        fieldType:"text",
                        fieldLabel:"Enter Contact No",
                        isMandatory:true,
                        isVisible:true,
                        callBack:"",
                        model:"9912332213",
                       pattern:"",
                        isMultiValued:false,
                        class:"",
                        minLength:"",
                        maxLength:"",
                        validations:
                        [
                            {
                                property:"required",
                                validationMessage:"Employee Contact No is Mandatory",
                                className:""
                            }
                        ]
                
                    },
                    {
                        fieldName:"General Employee DOB",
                        fieldType:"date",
                        fieldLabel:"Enter DOB",
                        isMandatory:true,
                        isVisible:true,
                        datePopUp:false,
                        dateOptions:{
                            showWeeks:false
    
                        },
                     
                        
                       format:"dd/MM/yyyy",
                        isMultiValued:false,
                        class:"",
                        minLength:"",
                        maxLength:"",
                        validations:
                        [
                            {
                                property:"required",
                                validationMessage:"Employee DOB is Mandatory",
                                className:""
                            }
                        ]
                
                    },
                    {
                        fieldName:"VOLUNTARY DEDUCTIBLE DESIRED",
                        fieldType:"checkbox",
                        fieldLabel:"VOLUNTARY DEDUCTIBLE DESIRED",
                        isMandatory:true,
                        isVisible:true,
                        fieldOptions:[
                            {
                                name:"AOG 10 LAKHS / OTHERS 5 LAKHS",
                                value:"AOG 10 LAKHS / OTHERS 5 LAKHS"
                              
                                
                            },
                            {
                                name:"AOG 20 LAKHS / OTHERS 10 LAKHS",
                                value:"AOG 20 LAKHS / OTHERS 10 LAKHS"
                            },
                            {
                                name:"AOG 30 LAKHS / OTHERS 15 LAKHS",
                                value:"AOG 30 LAKHS / OTHERS 15 LAKHS"
                            },
                            {
                                name:"AOG 10 LAKHS / OTHERS 5 LAKHS",
                                value:"AOG 10 LAKHS / OTHERS 5 LAKHS"
                            },
                            {
                                name:"AOG 100 LAKHS / OTHERS 50 LAKH",
                                value:"AOG 100 LAKHS / OTHERS 50 LAKH"
                            }
                        ]
                    }   
                ]
            },

            {
                name:"Other Information",
                fields:[
                    {
                        fieldName:"Other Employee Name",
                        fieldType:"text",
                        fieldLabel:"Enter Employee Name",
                        fieldId:"empName",
                        isMandatory:true,
                        isVisible:true,
                        callBack:"",
                        arguements:{},
                        model:"bob",
                       pattern:"",
                        isMultiValued:false,
                        class:"",
                        minLength:"3",
                        maxLength:"10",
                        conditionalVisibility:{
                          expression:"'Other Employee Fruits' == 'Orange' && 'Other Employee Vegetables' == 'Tomato'",
                          value:true,
                          dependents:['Other Employee Fruits','Other Employee Vegetables']
                        },
                        validations:
                        [
                            {
                                property:"required",
                                validationMessage:"Employee Name is Mandatory",
                                className:""
                            },
                            {
                                property:"minlength",
                                validationMessage:"Employee Name is should be minimum of 3 letters",
                                className:""
                            },
                            {
                                property:"maxlength",
                                validationMessage:"Employee Name is should be Maximum of 10 letters",
                                className:""
                            },
                            {
                                property:"pattern",
                                validationMessage:"Employee Name is not in a valid pattern",
                                className:""
                            }
                        ]
                       
                       
                    },
                    {
                        fieldName:"Other Employee Fruits",
                        fieldType:"dropdown",
                        fieldLabel:"Select Fruit",
                        fieldId:"empFruits",
                        isMandatory:true,
                        isVisible:true,
                        fieldOptions:["X","Y"],
                        callBack:"getFruitList",
                      pattern:"",
                        isMultiValued:false,
                        class:"",
                        model:"Banana",
                
                        minLength:"",
                        maxLength:"",
                        validations:
                         [
                            {
                                property:"required",
                                validationMessage:"Employee Fruit is Mandatory",
                                className:""
                            }
                        ]
                
                
                    },
                    {
                        fieldName:"Other Employee Vegetables",
                        fieldType:"dropdown",
                        fieldLabel:"Select Vegetable",
                        fieldId:"empVegetables",
                        isMandatory:true,
                        isVisible:true,
                        fieldOptions:["A","B"],
                        model:"Tomato",
                        callBack:"getVegetableList",
                        pattern:"",
                        isMultiValued:false,
                        class:"",
                        minLength:"",
                        maxLength:"",
                        validations:
                        [
                           {
                               property:"required",
                               validationMessage:"Employee Vegetables is Mandatory"
                           }
                       ]
                
                
                    },
                    {
                        fieldName:"Other Employee DOB",
                        fieldType:"date",
                        fieldLabel:"Enter DOB",
                        isMandatory:true,
                        isVisible:true,
                        datePopUp:false,
                        dateOptions:{
                            showWeeks:false
    
                        },
                     
                        
                       format:"dd/MM/yyyy",
                        isMultiValued:false,
                        class:"",
                        minLength:"",
                        maxLength:"",
                        validations:
                        [
                            {
                                property:"required",
                                validationMessage:"Employee DOB is Mandatory",
                                className:""
                            }
                        ]
                
                    } ,
                    {
                        fieldName:"To Exclude Covers",
                        fieldType:"checkbox",
                        fieldLabel:"To Exclude Covers",
                        isMandatory:true,
                        isVisible:true,
                        fieldOptions:[
                            {
                                name:"EARTHQUAKE (FIRE AND SHOCK)",
                                value:"EARTHQUAKE (FIRE AND SHOCK)"
                              
                                
                            },
                            {
                                name:"TERRORISM DAMAGE",
                                value:"TERRORISM DAMAGE"
                            },
                            {
                                name:"OTHER ADD-ON COVERS : 1,2,3,4,5,6,7,8,9,10,11,12,13. REF. PHYSICAL FORM",
                                value:"OTHER ADD-ON COVERS : 1,2,3,4,5,6,7,8,9,10,11,12,13. REF. PHYSICAL FORM"
                            },
                            {
                                name:"OTHER ADD-ON COVERS : 1,2,3,4,5,6,7,8,9,10,11,12,13. REF. PHYSICAL FORM",
                                value:"OTHER ADD-ON COVERS : 1,2,3,4,5,6,7,8,9,10,11,12,13. REF. PHYSICAL FORM"
                            },
                            {
                                name:"OTHER ADD-ON COVERS : 1,2,3,4,5,6,7,8,9,10,11,12,13. REF. PHYSICAL FORM",
                                value:"OTHER ADD-ON COVERS : 1,2,3,4,5,6,7,8,9,10,11,12,13. REF. PHYSICAL FORM"
                            }
                        ]
                    },
                    {
                        fieldName:"Other Employee DOJ",
                        fieldType:"date",
                        fieldLabel:"Enter DOJ",
                        isMandatory:true,
                        isVisible:true,
                        datePopUp:false,
                        dateOptions:{
                            showWeeks:false
    
                        },
                     
                        
                       format:"dd/MM/yyyy",
                        isMultiValued:false,
                        class:"",
                        minLength:"",
                        maxLength:"",
                        validations:
                        [
                            {
                                property:"required",
                                validationMessage:"Employee DOB is Mandatory",
                                className:""
                            }
                        ]
                
                    }    
                   
                   
                ]
            }

            ]
            
           
            
            
            }
        }

            return formObjects;
    }


    return service;
        });

  
   
  
    
  


