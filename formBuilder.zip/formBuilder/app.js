


    
    app.directive('formBuilder',["formBuilderService",function(formBuilderService) {
        var directive={};
        directive.restrict = 'E';
        directive.templateUrl = "form-template.html";
        directive.transclude=true;
        directive.scope = {
            lob:"=lob",
        callback:"&callback",
        formBindingObject:"=formBindingObject"
        }
        
        directive.controller=function($scope,$element, $attrs)
        {
        
        var fieldList=[];
        
        debugger

        // This method is used to check whethet field is valid or not against its validation constraints. 
        //It returns either true (or) false
        $scope.isInValid=function(fieldName,formName)
        {
            console.log(JSON.stringify($scope.formBindingObject));
            debugger
            var flag=false;
        
            if(formName!=null && fieldName!=null && fieldName!="")
            flag=formName[fieldName].$invalid && formName[fieldName].$touched;
         
            return flag;
        }
        

        //This method is used to checkbox toggle
        //Every time a User toggles the checkbox it will push into the array. If the value is already
        //Present in the array it splices and viceversa
        $scope.toggleSelection=function(field,f)
        {
            if($scope.formBindingObject[field.fieldName]==null || $scope.formBindingObject[field.fieldName]==undefined)
            {
                $scope.formBindingObject[field.fieldName]=[];
                $scope.formBindingObject[field.fieldName].push(f.value);  
            }
            else{
                var idx = $scope.formBindingObject[field.fieldName].indexOf(f.value);

                // Is currently selected
                if (idx > -1) {
                    $scope.formBindingObject[field.fieldName].splice(idx, 1);
                }
            
                // Is newly selected
                else {
                    $scope.formBindingObject[field.fieldName].push(f.value);
                }
            }
        }


        //This method is used check whether the value present in the check box array (or) Not
        //It returns either true (or) false
$scope.isValueExists=function(field,f)
{
    if($scope.formBindingObject[field.fieldName]==null || $scope.formBindingObject[field.fieldName]==undefined)
    {
        return false;
    } 
    else{
        var idx = $scope.formBindingObject[field.fieldName].indexOf(f.value);
        if(idx>-1)
        return true;
        else
        return false;
 }
}

//This method is used to dynamically return the CSS class name for a label
//For Mandatory fields it returns the label with ashtrex symbol otherwise its not
$scope.isRequired=function(field)
{
    return (field.isMandatory) ? 'control-label' :'';
}

$scope.onSubmit=function()
{
    debugger;
    JSON.stringify($scope.formBindingObject);
}


$scope.onCancel=function()
{
    $scope.formBindingObject={};
}

$scope.message="Hello world";


debugger
$scope.formObjects=formBuilderService.getFieldsByLOB('MOTOR');


//This method is used to return the width of a field based on its control type
//Currently we are returning 100 % width for "CheckBoxes" and for Other's it returns 33% width
$scope.getWidth=function(field)
{
    debugger
    return (field.fieldType=='checkbox')?'col-sm-12':'col-sm-4';
    
}


        
        
        //This method is used to determine the conditional visibility  of a field based on its conditional expression
        //It returns either true (or) false
        $scope.getVisibility=function(field)
        {
            debugger
           if(field.conditionalVisibility!=null && field.conditionalVisibility!=undefined)
           {
               var exp;
               exp=field.conditionalVisibility.expression;
               field.conditionalVisibility.dependents.forEach(function(curr,index,arr)
            {
                exp=exp.split(curr).join($scope.formBindingObject[curr]);
                field.isVisible=eval(exp);
            })

            
           }
           return field.isVisible;
        }
        
        
        
        
        
        //This method is used to check whether the field is valid or not and accordingly it sends the validation message
        $scope.getMessage=function(validations,fieldName,formName)
        {
            var msg="";
        if(formName!=null && fieldName!=null && fieldName!="")
        {
            if(formName[fieldName]!=null && formName[fieldName].$invalid && formName[fieldName].$touched)
            {
                var properties=[];
        if(validations!=null)
        {
                properties=validations.filter(obj=>(formName[fieldName].$error[obj.property]!=null && formName[fieldName].$error[obj.property]!=""))
                if(properties.length>0) 
                msg=properties[0].validationMessage;
        }
            }
        }
            return msg;
        }
        


        
        
            $scope.getData=function(field)
            {
                debugger
        if(field.callBack!="" && field.callBack!=null)
        {
        
                var fn=field.callBack;
                
                field.fieldOptions=$scope.callback({callback:fn});
        }
        return field.fieldOptions;
            }
        
            
            console.log(JSON.stringify($scope.formObjects));
            debugger
        };
        return directive;
        }]);



