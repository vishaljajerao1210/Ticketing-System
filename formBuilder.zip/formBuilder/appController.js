var app=angular.module("formBuilderApp",['ui.bootstrap'])
app.config(["$controllerProvider",function($controllerProvider){

    $controllerProvider.register("formController",["$scope",function($scope){

        $scope.fieldOptions=[];
    $scope.getCallback=function(callback)
    {
        debugger
        var fn=$scope[callback];
        return fn();
    
    }
var fieldList=[];
//call back functions.///
$scope.getFruitList=function()
{
    fieldList=[];
    fieldList.push("Orange");
    fieldList.push("Mango");
    fieldList.push("Banana");
    return   fieldList;
}

$scope.getVegetableList=function()
{
    fieldList=[];
    fieldList.push("Tomato");
    fieldList.push("Potato");
    fieldList.push("Onion");
    return   fieldList;
}


$scope.onSubmit=function()
{
    debugger
    console.log(JSON.stringify($scope.formBindingObject));
}

$scope.onCancel=function()
{
    $scope.formBindingObject={};
}

$scope.formBindingObject={};

$scope.lob="MOTOR";


//configurable Form JSON Object..///

debugger

    }])



}])



